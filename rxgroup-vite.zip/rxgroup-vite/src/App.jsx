import { useState, useEffect } from "react";

// ─────────────────────────────────────────────
// localStorage helpers
// ─────────────────────────────────────────────
const STORAGE_KEY = "rxg_data_663";

function loadData() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { meds: [], pass: "Ph663", loggedIn: false };
    const d = JSON.parse(raw);
    return {
      meds: Array.isArray(d.meds) ? d.meds : [],
      pass: d.pass || "Ph663",
      loggedIn: d.loggedIn === true,
    };
  } catch {
    return { meds: [], pass: "Ph663", loggedIn: false };
  }
}

function saveData(obj) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(obj));
  } catch (e) {
    console.error("saveData error:", e);
  }
}

// ─────────────────────────────────────────────
// Date helpers
// ─────────────────────────────────────────────
function todayStr() {
  return new Date().toISOString().split("T")[0];
}
function addDays(s, n) {
  const d = new Date(s);
  d.setDate(d.getDate() + n);
  return d.toISOString().split("T")[0];
}
function daysUntil(s) {
  const t = new Date();
  t.setHours(0, 0, 0, 0);
  const d = new Date(s);
  d.setHours(0, 0, 0, 0);
  return Math.round((d - t) / 86400000);
}
function fmtDate(s) {
  if (!s) return "";
  const [y, m, d] = s.split("-");
  return `${d}/${m}/${y}`;
}
function chipInfo(d) {
  if (d < 0)   return { l: "Overdue",   bg: "#fee2e2", c: "#b91c1c" };
  if (d === 0) return { l: "Due today", bg: "#fee2e2", c: "#c0392b" };
  if (d <= 7)  return { l: `${d}d`,     bg: "#ffedd5", c: "#c2410c" };
  if (d <= 14) return { l: `${d}d`,     bg: "#fef9c3", c: "#854d0e" };
  return { l: `${d}d`, bg: "#dcfce7", c: "#15803d" };
}
function borderCol(d) {
  return d < 0 ? "#ef4444" : d <= 7 ? "#f97316" : d <= 14 ? "#eab308" : "#22c55e";
}
function payStyle(p) {
  if (p === "Insurance") return { background: "#eff6ff", color: "#1d4ed8" };
  if (p === "Mixed")     return { background: "#f5f3ff", color: "#6d28d9" };
  return { background: "#f0fdf4", color: "#15803d" };
}

// ─────────────────────────────────────────────
// Styles object
// ─────────────────────────────────────────────
const S = {
  inp: {
    width: "100%", background: "#f9fafb", border: "1.5px solid #e5e7eb",
    borderRadius: 9, color: "#111827", padding: "10px 12px", fontSize: 13,
    fontFamily: "inherit", boxSizing: "border-box",
  },
  lbl: {
    display: "block", fontSize: 11, fontWeight: 700, color: "#6b7280",
    textTransform: "uppercase", letterSpacing: ".6px", marginBottom: 5,
  },
  btn: {
    width: "100%", background: "#2563eb", color: "#fff", border: "none",
    borderRadius: 12, padding: 14, fontSize: 14, fontWeight: 700,
    cursor: "pointer", marginTop: 4, fontFamily: "inherit",
  },
  navBtn: {
    border: "none", borderRadius: 9, padding: "6px 11px", fontSize: 12,
    fontWeight: 600, cursor: "pointer", color: "rgba(255,255,255,.9)",
    background: "rgba(255,255,255,.2)",
  },
  fchip: (on) => ({
    padding: "5px 13px", borderRadius: 20, fontSize: 12, fontWeight: 600,
    cursor: "pointer", border: "1.5px solid",
    borderColor: on ? "#2563eb" : "#e5e7eb",
    background: on ? "#2563eb" : "#fff",
    color: on ? "#fff" : "#475569",
    fontFamily: "inherit",
  }),
  durBtn: (on) => ({
    borderRadius: 9, padding: "9px 6px", cursor: "pointer",
    border: "1.5px solid", borderColor: on ? "#2563eb" : "#e5e7eb",
    textAlign: "center", background: on ? "#2563eb" : "#fff",
    color: on ? "#fff" : "#475569", fontWeight: on ? 700 : 400,
    fontFamily: "inherit",
  }),
  sel: {
    width: "100%", background: "#f9fafb", border: "1.5px solid #e5e7eb",
    borderRadius: 9, color: "#111827", padding: "10px 12px",
    fontSize: 13, fontFamily: "inherit",
  },
  chip: (bg, c) => ({
    display: "inline-block", padding: "2px 7px", borderRadius: 20,
    fontSize: 10, fontWeight: 700, whiteSpace: "nowrap", background: bg, color: c,
  }),
  ib: {
    background: "#f8fafc", border: "none", borderRadius: 8, width: 30, height: 30,
    display: "flex", alignItems: "center", justifyContent: "center",
    cursor: "pointer", fontSize: 12,
  },
  fab: {
    position: "fixed", bottom: 22, right: 18, width: 52, height: 52,
    borderRadius: "50%", background: "#2563eb", color: "#fff", fontSize: 26,
    border: "none", cursor: "pointer", display: "flex", alignItems: "center",
    justifyContent: "center", boxShadow: "0 6px 18px rgba(37,99,235,.4)", zIndex: 50,
  },
};

// ─────────────────────────────────────────────
// App
// ─────────────────────────────────────────────
export default function App() {
  // ── Core state ──────────────────────────────
  const [loggedIn, setLoggedIn] = useState(false);
  const [meds,     setMeds]     = useState([]);
  const [pass,     setPass]     = useState("Ph663");

  // ── UI state ────────────────────────────────
  const [page,       setPage]       = useState("list");
  const [loginPass,  setLoginPass]  = useState("");
  const [loginErr,   setLoginErr]   = useState("");
  const [search,     setSearch]     = useState("");
  const [filterMode, setFilterMode] = useState("all");
  const [dueDays,    setDueDays]    = useState(7);
  const [fromDate,   setFromDate]   = useState("");
  const [toDate,     setToDate]     = useState("");
  const [editId,     setEditId]     = useState(null);
  const [delId,      setDelId]      = useState(null);
  const [chgPwOpen,  setChgPwOpen]  = useState(false);
  const [cpOld,  setCpOld]  = useState("");
  const [cpNew,  setCpNew]  = useState("");
  const [cpNew2, setCpNew2] = useState("");
  const [cpErr,  setCpErr]  = useState("");
  const [cpOk,   setCpOk]   = useState(false);

  // ── Form state ──────────────────────────────
  const [fDrug,       setFDrug]       = useState("");
  const [fItem,       setFItem]       = useState("");
  const [fPat,        setFPat]        = useState("");
  const [fId,         setFId]         = useState("");
  const [fPhone,      setFPhone]      = useState("");
  const [fPharm,      setFPharm]      = useState("");
  const [fPay,        setFPay]        = useState("Cash");
  const [fDate,       setFDate]       = useState(todayStr());
  const [durDays,     setDurDays]     = useState(25);
  const [customDur,   setCustomDur]   = useState(false);
  const [fCustomDate, setFCustomDate] = useState("");
  const [saving,      setSaving]      = useState(false);

  // ── Init: load from localStorage ────────────
  useEffect(() => {
    const d = loadData();
    setMeds(d.meds);
    setPass(d.pass);
    setLoggedIn(d.loggedIn);
  }, []);

  // ── Persist helper ───────────────────────────
  function persist(newMeds, newPass, newLoggedIn) {
    saveData({ meds: newMeds, pass: newPass, loggedIn: newLoggedIn });
  }

  // ── Auth ─────────────────────────────────────
  function doLogin() {
    if (loginPass === pass) {
      persist(meds, pass, true);
      setLoggedIn(true);
      setLoginErr("");
      setLoginPass("");
    } else {
      setLoginErr("Invalid password");
    }
  }

  function doLogout() {
    persist(meds, pass, false);
    setLoggedIn(false);
    setLoginPass("");
  }

  function doChgPw() {
    if (cpOld !== pass)     { setCpErr("Current password incorrect"); return; }
    if (cpNew.length < 4)   { setCpErr("Min 4 characters");           return; }
    if (cpNew !== cpNew2)   { setCpErr("Passwords don't match");      return; }
    persist(meds, cpNew, true);
    setPass(cpNew);
    setCpOk(true);
    setCpErr("");
    setTimeout(() => {
      setChgPwOpen(false);
      setCpOld(""); setCpNew(""); setCpNew2(""); setCpOk(false);
    }, 1400);
  }

  // ── Save / Delete med ────────────────────────
  function doSave() {
    if (!fDrug.trim() || !fPat.trim() || !fDate) {
      alert("Please fill Drug Name, Patient Name, and Dispense Date");
      return;
    }
    const refill = customDur ? fCustomDate : addDays(fDate, durDays);
    if (!refill) { alert("Please select a refill date"); return; }

    setSaving(true);
    const entry = {
      id:              editId || `med_${Date.now()}`,
      drugName:        fDrug.trim(),
      itemCode:        fItem.trim(),
      patientName:     fPat.trim(),
      idNumber:        fId.trim(),
      phone:           fPhone.trim(),
      pharmacistName:  fPharm.trim(),
      paymentType:     fPay,
      dispenseDate:    fDate,
      durationMode:    customDur ? "custom" : "preset",
      duration:        durDays,
      customRefillDate: customDur ? fCustomDate : "",
      refillDate:      refill,
    };

    const newMeds = editId
      ? meds.map((m) => (m.id === editId ? entry : m))
      : [...meds, entry];

    persist(newMeds, pass, true);
    setMeds(newMeds);
    setSaving(false);
    setPage("list");
  }

  function doDelete() {
    if (!delId) return;
    const newMeds = meds.filter((m) => m.id !== delId);
    persist(newMeds, pass, true);
    setMeds(newMeds);
    setDelId(null);
  }

  // ── Open form ────────────────────────────────
  function openAdd() {
    setEditId(null); setFDrug(""); setFItem(""); setFPat(""); setFId("");
    setFPhone(""); setFPharm(""); setFPay("Cash"); setFDate(todayStr());
    setDurDays(25); setCustomDur(false); setFCustomDate("");
    setPage("form");
  }

  function openEdit(id) {
    const m = meds.find((x) => x.id === id);
    if (!m) return;
    setEditId(id);
    setFDrug(m.drugName || "");
    setFItem(m.itemCode || "");
    setFPat(m.patientName || "");
    setFId(m.idNumber || "");
    setFPhone(m.phone || "");
    setFPharm(m.pharmacistName || "");
    setFPay(m.paymentType || "Cash");
    setFDate(m.dispenseDate || todayStr());
    setCustomDur(m.durationMode === "custom");
    setDurDays(m.duration || 25);
    setFCustomDate(m.customRefillDate || "");
    setPage("form");
  }

  // ── Filter / sort ────────────────────────────
  let rows = [...meds];
  if (search) {
    const q = search.toLowerCase();
    rows = rows.filter(
      (m) =>
        (m.drugName || "").toLowerCase().includes(q) ||
        (m.patientName || "").toLowerCase().includes(q) ||
        (m.idNumber || "").includes(q) ||
        (m.phone || "").includes(q) ||
        (m.itemCode || "").toLowerCase().includes(q)
    );
  }
  if (filterMode === "dueSoon") {
    rows = rows.filter((m) => {
      const d = daysUntil(m.refillDate);
      return d >= 0 && d <= dueDays;
    });
  }
  if (filterMode === "dateRange") {
    if (fromDate) rows = rows.filter((m) => m.refillDate >= fromDate);
    if (toDate)   rows = rows.filter((m) => m.refillDate <= toDate);
  }
  rows.sort((a, b) => daysUntil(a.refillDate) - daysUntil(b.refillDate));

  const soon = meds.filter((m) => {
    const d = daysUntil(m.refillDate);
    return d >= 0 && d <= 7;
  }).length;

  const refillPreview = customDur
    ? fCustomDate
    : fDate
    ? addDays(fDate, durDays)
    : "";

  // ─────────────────────────────────────────────
  // LOGIN screen
  // ─────────────────────────────────────────────
  if (!loggedIn) {
    return (
      <div style={{ minHeight: "100vh", background: "linear-gradient(135deg,#1e40af,#2563eb)", display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
        <div style={{ background: "#fff", borderRadius: 22, padding: "34px 26px", width: "100%", maxWidth: 340, boxShadow: "0 20px 60px rgba(0,0,0,.25)", textAlign: "center" }}>
          <div style={{ fontSize: 44, marginBottom: 10 }}>💊</div>
          <h1 style={{ fontSize: 20, fontWeight: 800, color: "#0f172a", marginBottom: 3 }}>RxGroup</h1>
          <p style={{ fontSize: 12, color: "#94a3b8", marginBottom: 24 }}>Medication Refill Tracker</p>
          <div style={{ textAlign: "left" }}>
            <div style={{ marginBottom: 12 }}>
              <label style={S.lbl}>Username</label>
              <input style={{ ...S.inp, background: "#f1f5f9", color: "#64748b", cursor: "not-allowed" }} value="663" readOnly />
              <div style={{ fontSize: 10, color: "#94a3b8", marginTop: 3 }}>Fixed username</div>
            </div>
            <div style={{ marginBottom: 12 }}>
              <label style={S.lbl}>Password</label>
              <input
                style={S.inp} type="password" placeholder="Enter password"
                value={loginPass} onChange={(e) => setLoginPass(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && doLogin()}
              />
            </div>
            {loginErr && (
              <div style={{ color: "#ef4444", fontSize: 12, fontWeight: 600, background: "#fef2f2", borderRadius: 8, padding: "7px 10px", marginBottom: 10 }}>
                {loginErr}
              </div>
            )}
            <button style={S.btn} onClick={doLogin}>Sign In</button>
          </div>
        </div>
      </div>
    );
  }

  // ─────────────────────────────────────────────
  // FORM screen
  // ─────────────────────────────────────────────
  if (page === "form") {
    return (
      <div style={{ fontFamily: "Inter,sans-serif", background: "#f1f5f9", minHeight: "100vh", display: "flex", flexDirection: "column" }}>
        {/* Header */}
        <div style={{ background: "#2563eb", padding: "12px 16px 22px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <button
                onClick={() => setPage("list")}
                style={{ background: "rgba(255,255,255,.2)", border: "none", borderRadius: 9, color: "#fff", fontSize: 16, cursor: "pointer", width: 34, height: 34, display: "flex", alignItems: "center", justifyContent: "center" }}
              >←</button>
              <h1 style={{ fontSize: 18, fontWeight: 800, color: "#fff", margin: 0 }}>
                {editId ? "Edit" : "Add"} Medication
              </h1>
            </div>
            <button style={S.navBtn} onClick={doLogout}>↩ Logout</button>
          </div>
        </div>

        {/* Form body */}
        <div style={{ background: "#f1f5f9", borderRadius: "18px 18px 0 0", marginTop: -10, padding: "18px 16px 80px", flex: 1, overflowY: "auto" }}>
          {/* Drug + Item Code */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 12 }}>
            <div>
              <label style={S.lbl}>Drug Name *</label>
              <input style={S.inp} placeholder="e.g. Metformin" value={fDrug} onChange={(e) => setFDrug(e.target.value)} />
            </div>
            <div>
              <label style={S.lbl}>Item Code</label>
              <input style={S.inp} placeholder="5282637" value={fItem} onChange={(e) => setFItem(e.target.value)} inputMode="numeric" type="tel" />
            </div>
          </div>

          {/* Patient */}
          <div style={{ marginBottom: 12 }}>
            <label style={S.lbl}>Patient Name *</label>
            <input style={S.inp} placeholder="Full name" value={fPat} onChange={(e) => setFPat(e.target.value)} />
          </div>

          {/* ID + Mobile */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 12 }}>
            <div>
              <label style={S.lbl}>ID / Iqama</label>
              <input style={S.inp} placeholder="ID number" value={fId} onChange={(e) => setFId(e.target.value)} inputMode="numeric" type="tel" />
            </div>
            <div>
              <label style={S.lbl}>Mobile</label>
              <input style={S.inp} placeholder="05xxxxxxxx" value={fPhone} onChange={(e) => setFPhone(e.target.value)} inputMode="numeric" type="tel" />
            </div>
          </div>

          {/* Pharmacist ID + Payment */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 12 }}>
            <div>
              <label style={S.lbl}>Pharmacist ID</label>
              <input style={S.inp} placeholder="Employee ID" value={fPharm} onChange={(e) => setFPharm(e.target.value)} inputMode="numeric" type="tel" />
            </div>
            <div>
              <label style={S.lbl}>Payment</label>
              <select style={S.sel} value={fPay} onChange={(e) => setFPay(e.target.value)}>
                <option>Cash</option>
                <option>Insurance</option>
                <option>Mixed</option>
              </select>
            </div>
          </div>

          {/* Dispense Date */}
          <div style={{ marginBottom: 12 }}>
            <label style={S.lbl}>Dispense Date *</label>
            <input type="date" style={S.inp} value={fDate} onChange={(e) => setFDate(e.target.value)} />
          </div>

          {/* Duration */}
          <div style={{ marginBottom: 12 }}>
            <label style={S.lbl}>Refill Duration</label>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 7 }}>
              {[[25, "1 Month"], [50, "2 Months"], [75, "3 Months"]].map(([d, l]) => (
                <button key={d} style={S.durBtn(!customDur && durDays === d)} onClick={() => { setCustomDur(false); setDurDays(d); }}>
                  <div style={{ fontSize: 11 }}>{l}</div>
                  <div style={{ fontSize: 10, opacity: 0.7, marginTop: 2 }}>{d}d</div>
                </button>
              ))}
              <button style={S.durBtn(customDur)} onClick={() => setCustomDur(true)}>
                <div style={{ fontSize: 11 }}>Custom</div>
                <div style={{ fontSize: 10, opacity: 0.7, marginTop: 2 }}>Date</div>
              </button>
            </div>
            {customDur && (
              <div style={{ marginTop: 10 }}>
                <label style={S.lbl}>Custom Refill Date</label>
                <input type="date" style={S.inp} value={fCustomDate} onChange={(e) => setFCustomDate(e.target.value)} />
              </div>
            )}
          </div>

          {/* Preview */}
          {refillPreview && (
            <div style={{ background: "#eff6ff", border: "1.5px solid #bfdbfe", borderRadius: 11, padding: "10px 14px", marginBottom: 12 }}>
              <div style={{ fontSize: 10, color: "#64748b", fontWeight: 700, textTransform: "uppercase", letterSpacing: ".5px", marginBottom: 3 }}>Refill Date</div>
              <div style={{ fontSize: 17, fontWeight: 800, color: "#2563eb" }}>{fmtDate(refillPreview)}</div>
              <div style={{ fontSize: 11, color: "#94a3b8", marginTop: 2 }}>{daysUntil(refillPreview)} days from today</div>
            </div>
          )}

          <button style={{ ...S.btn, opacity: saving ? 0.7 : 1 }} onClick={doSave} disabled={saving}>
            {saving ? "Saving…" : editId ? "✅ Update Medication" : "➕ Add Medication"}
          </button>
        </div>
      </div>
    );
  }

  // ─────────────────────────────────────────────
  // LIST screen
  // ─────────────────────────────────────────────
  return (
    <div style={{ fontFamily: "Inter,sans-serif", background: "#f1f5f9", minHeight: "100vh", display: "flex", flexDirection: "column" }}>
      {/* Header */}
      <div style={{ background: "#2563eb", padding: "12px 16px 22px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <span style={{ fontSize: 20 }}>💊</span>
            <div>
              <div style={{ fontSize: 18, fontWeight: 800, color: "#fff", letterSpacing: "-.4px" }}>RxGroup</div>
              <div style={{ fontSize: 11, color: "rgba(255,255,255,.7)" }}>
                {meds.length} medication{meds.length !== 1 ? "s" : ""}
              </div>
            </div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 5, flexWrap: "wrap" }}>
            {soon > 0 && (
              <div
                style={{ background: "rgba(255,255,255,.2)", borderRadius: 14, padding: "5px 10px", cursor: "pointer", display: "flex", alignItems: "center", gap: 4 }}
                onClick={() => setFilterMode("dueSoon")}
              >
                <span>🔔</span>
                <span style={{ fontSize: 13, fontWeight: 800, color: "#fff" }}>{soon}</span>
              </div>
            )}
            <button style={S.navBtn} onClick={openAdd}>+ Add</button>
            <button style={S.navBtn} onClick={() => setChgPwOpen(true)}>⚙️</button>
            <button style={S.navBtn} onClick={doLogout}>↩</button>
          </div>
        </div>
      </div>

      {/* Panel */}
      <div style={{ background: "#f1f5f9", borderRadius: "18px 18px 0 0", marginTop: -10, padding: "14px 12px 100px", flex: 1 }}>
        {/* Search */}
        <div style={{ background: "#fff", borderRadius: 11, padding: "0 11px", display: "flex", alignItems: "center", gap: 7, border: "1.5px solid #e5e7eb", marginBottom: 10 }}>
          <span style={{ fontSize: 14, color: "#94a3b8" }}>🔍</span>
          <input
            style={{ border: "none", outline: "none", fontSize: 12, color: "#374151", padding: "10px 0", width: "100%", background: "transparent", fontFamily: "inherit" }}
            placeholder="Search by name, person, or number"
            value={search} onChange={(e) => setSearch(e.target.value)}
          />
          <button onClick={() => setSearch("")} style={{ background: "none", border: "none", color: "#94a3b8", cursor: "pointer", fontSize: 14 }}>✕</button>
        </div>

        {/* Filter chips */}
        <div style={{ marginBottom: 8 }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: "#374151", marginBottom: 7 }}>Refill:</div>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            {[["all", "All dates"], ["dueSoon", "Due soon"], ["dateRange", "Date range"]].map(([k, l]) => (
              <button key={k} style={S.fchip(filterMode === k)} onClick={() => setFilterMode(k)}>{l}</button>
            ))}
          </div>
        </div>

        {filterMode === "dueSoon" && (
          <div style={{ background: "#fff", borderRadius: 11, padding: "11px 13px", marginBottom: 9, border: "1.5px solid #e5e7eb" }}>
            <label style={{ ...S.lbl, marginBottom: 6 }}>Show due within</label>
            <select style={S.sel} value={dueDays} onChange={(e) => setDueDays(+e.target.value)}>
              <option value={7}>1 Week</option>
              <option value={14}>2 Weeks</option>
              <option value={21}>3 Weeks</option>
              <option value={30}>1 Month</option>
            </select>
          </div>
        )}

        {filterMode === "dateRange" && (
          <div style={{ background: "#fff", borderRadius: 11, padding: "11px 13px", marginBottom: 9, border: "1.5px solid #e5e7eb" }}>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 9 }}>
              <div>
                <label style={S.lbl}>FROM</label>
                <input type="date" style={{ ...S.inp, fontSize: 12, padding: "8px 10px" }} value={fromDate} onChange={(e) => setFromDate(e.target.value)} />
              </div>
              <div>
                <label style={S.lbl}>TO</label>
                <input type="date" style={{ ...S.inp, fontSize: 12, padding: "8px 10px" }} value={toDate} onChange={(e) => setToDate(e.target.value)} />
              </div>
            </div>
            <button onClick={() => { setFromDate(""); setToDate(""); }} style={{ background: "#f1f5f9", border: "1.5px solid #e5e7eb", borderRadius: 8, padding: "6px 14px", fontSize: 11, fontWeight: 600, color: "#475569", cursor: "pointer", fontFamily: "inherit" }}>
              Clear
            </button>
          </div>
        )}

        {/* Results row */}
        <div style={{ fontSize: 11, color: "#64748b", fontWeight: 500, marginBottom: 9, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <span>{rows.length} result{rows.length !== 1 ? "s" : ""}{filterMode !== "all" || search ? " (filtered)" : ""}</span>
          <button
            onClick={() => { const d = loadData(); setMeds(d.meds); }}
            style={{ background: "none", border: "none", color: "#94a3b8", cursor: "pointer", fontSize: 12, fontFamily: "inherit" }}
          >↻ Sync</button>
        </div>

        {/* Empty state */}
        {rows.length === 0 ? (
          <div style={{ textAlign: "center", padding: "60px 0", color: "#94a3b8" }}>
            <div style={{ fontSize: 40, marginBottom: 9 }}>💊</div>
            <div style={{ fontSize: 13, fontWeight: 600, color: "#64748b" }}>
              {meds.length === 0 ? "No medications yet" : "No results"}
            </div>
            <div style={{ fontSize: 11, marginTop: 4 }}>
              {meds.length === 0 ? "Tap + to add your first medication" : "Try adjusting filters"}
            </div>
          </div>
        ) : (
          rows.map((m) => {
            const d = daysUntil(m.refillDate);
            const { l, bg, c } = chipInfo(d);
            const pay = m.paymentType || "Cash";
            return (
              <div key={m.id} style={{ background: "#fff", borderRadius: 13, padding: "10px 10px 10px 0", marginBottom: 7, borderLeft: `4px solid ${borderCol(d)}`, boxShadow: "0 1px 3px rgba(0,0,0,.06)", animation: "fu .18s ease" }}>
                <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", paddingLeft: 12 }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: "flex", alignItems: "baseline", gap: 6, marginBottom: 4, flexWrap: "wrap" }}>
                      <span style={{ fontSize: 14, fontWeight: 800, color: "#e74c3c" }}>{m.drugName}</span>
                      <span style={{ fontSize: 13, fontWeight: 700, color: "#e74c3c" }}>— {m.patientName}</span>
                      {m.itemCode && (
                        <span style={{ fontSize: 10, fontWeight: 600, color: "#94a3b8", background: "#f1f5f9", borderRadius: 5, padding: "1px 6px" }}>{m.itemCode}</span>
                      )}
                    </div>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 8, fontSize: 11, color: "#374151", marginBottom: 3, alignItems: "center" }}>
                      <span>📅 <strong style={{ color: d <= 7 ? "#e74c3c" : "#374151" }}>{fmtDate(m.refillDate)}</strong></span>
                      {m.idNumber && <span style={{ color: "#64748b" }}>🪪 {m.idNumber}</span>}
                    </div>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 8, fontSize: 11, color: "#64748b", alignItems: "center" }}>
                      {m.pharmacistName && <span>🏥 {m.pharmacistName}</span>}
                      {m.phone && <span>📱 {m.phone}</span>}
                      <span style={{ ...payStyle(pay), display: "inline-block", padding: "1px 7px", borderRadius: 10, fontSize: 10, fontWeight: 700 }}>{pay}</span>
                    </div>
                  </div>
                  <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 5, marginLeft: 6, flexShrink: 0 }}>
                    <span style={S.chip(bg, c)}>{l}</span>
                    <div style={{ display: "flex", gap: 4 }}>
                      <button onClick={() => openEdit(m.id)} style={S.ib}>✏️</button>
                      <button onClick={() => setDelId(m.id)} style={S.ib}>🗑️</button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* FAB */}
      <button onClick={openAdd} style={S.fab}>+</button>

      {/* Delete Modal */}
      {delId && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(15,23,42,.55)", zIndex: 200, display: "flex", alignItems: "flex-end", justifyContent: "center", padding: "0 14px 26px" }}>
          <div style={{ background: "#fff", borderRadius: 18, padding: 22, width: "100%", maxWidth: 360, boxShadow: "0 24px 64px rgba(0,0,0,.3)", textAlign: "center", animation: "si .2s ease" }}>
            <div style={{ fontSize: 38, marginBottom: 7 }}>🗑️</div>
            <h3 style={{ fontSize: 15, fontWeight: 800, color: "#0f172a", marginBottom: 5 }}>Delete Medication?</h3>
            <p style={{ fontSize: 12, color: "#64748b", marginBottom: 16 }}>
              <strong style={{ color: "#e74c3c" }}>{meds.find((m) => m.id === delId)?.drugName}</strong> will be permanently removed.
            </p>
            <div style={{ display: "flex", gap: 9 }}>
              <button onClick={() => setDelId(null)} style={{ flex: 1, background: "#f1f5f9", border: "none", borderRadius: 11, padding: 11, fontSize: 13, fontWeight: 600, color: "#475569", cursor: "pointer", fontFamily: "inherit" }}>Cancel</button>
              <button onClick={doDelete} style={{ flex: 1, background: "#ef4444", border: "none", borderRadius: 11, padding: 11, fontSize: 13, fontWeight: 600, color: "#fff", cursor: "pointer", fontFamily: "inherit" }}>Delete</button>
            </div>
          </div>
        </div>
      )}

      {/* Change Password Modal */}
      {chgPwOpen && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(15,23,42,.6)", zIndex: 300, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
          <div style={{ background: "#fff", borderRadius: 18, padding: 26, width: "100%", maxWidth: 340, boxShadow: "0 24px 64px rgba(0,0,0,.3)", animation: "si .2s ease" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
              <h3 style={{ fontSize: 15, fontWeight: 800, color: "#0f172a" }}>🔑 Change Password</h3>
              <button onClick={() => setChgPwOpen(false)} style={{ background: "#f1f5f9", border: "none", borderRadius: 7, color: "#64748b", cursor: "pointer", width: 28, height: 28, fontSize: 14 }}>✕</button>
            </div>
            {[["Current", cpOld, setCpOld], ["New", cpNew, setCpNew], ["Confirm New", cpNew2, setCpNew2]].map(([lbl, val, setter], i) => (
              <div key={i} style={{ marginBottom: 12 }}>
                <label style={S.lbl}>{lbl} Password</label>
                <input type="password" style={S.inp} value={val} onChange={(e) => setter(e.target.value)} />
              </div>
            ))}
            {cpErr && <div style={{ color: "#ef4444", fontSize: 12, fontWeight: 600, background: "#fef2f2", borderRadius: 8, padding: "7px 10px", marginBottom: 10 }}>{cpErr}</div>}
            {cpOk  && <div style={{ color: "#15803d", fontSize: 12, fontWeight: 700, background: "#dcfce7", borderRadius: 8, padding: "7px 10px", textAlign: "center", marginBottom: 10 }}>✅ Password changed!</div>}
            <button style={S.btn} onClick={doChgPw}>Update Password</button>
          </div>
        </div>
      )}
    </div>
  );
}
